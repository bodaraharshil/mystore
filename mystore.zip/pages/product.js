import Link from "next/link";

const Product = () => {
    return(
      <div>
        <h1>Product page</h1>
        <Link href="/">Back</Link>
      </div>
    )
  }
  
  export default Product