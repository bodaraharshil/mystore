module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/api/login.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./helpers/initDB.js":
/*!***************************!*\
  !*** ./helpers/initDB.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ "mongoose");
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_1__);



function initDB() {
  if (mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connections[0].readyState) {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.green("alerady connected to a database"));
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connect(process.env.MONGO_URI, {
    // useCreateIndex:true,
    useNewUrlParser: true,
    useUnifiedTopology: true // useFindAndModify:true

  });
  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connection.on("conneted", () => {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.bgGreen("Mongodb to connect"));
  });
  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connection.on("error", error => {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.bgRed("Error", error));
  });
}

/* harmony default export */ __webpack_exports__["default"] = (initDB);

/***/ }),

/***/ "./models/user.js":
/*!************************!*\
  !*** ./models/user.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ "mongoose");
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const userSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    required: true,
    default: 'user',
    enum: ["user", "admin", "root"]
  }
}, {
  timestamps: true
});
/* harmony default export */ __webpack_exports__["default"] = (mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.models.user || mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.model("user", userSchema));

/***/ }),

/***/ "./pages/api/login.js":
/*!****************************!*\
  !*** ./pages/api/login.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers_initDB__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers/initDB */ "./helpers/initDB.js");
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../models/user */ "./models/user.js");
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bcryptjs */ "bcryptjs");
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jsonwebtoken */ "jsonwebtoken");
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);




Object(_helpers_initDB__WEBPACK_IMPORTED_MODULE_0__["default"])();
/* harmony default export */ __webpack_exports__["default"] = (async (req, res) => {
  try {
    const {
      email,
      password
    } = req.body;

    if (!email || !password) {
      return res.status(422).json({
        message: "please add all filed"
      });
    }

    const userdata = await _models_user__WEBPACK_IMPORTED_MODULE_1__["default"].findOne({
      email
    });

    if (!userdata) {
      return res.status(401).json({
        error: 'User dose not exit with that email'
      });
    } else {
      const domatch = await bcryptjs__WEBPACK_IMPORTED_MODULE_2___default.a.compare(password, userdata.password);

      if (domatch) {
        const token = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default.a.sign({
          useId: userdata._id
        }, process.env.JWT_SECRET, {
          expiresIn: "7d"
        });
        return res.status(200).json({
          token: token,
          message: "you have to successfuly login"
        });
      } else {
        res.status(401).json({
          error: "email and password do not match"
        });
      }

      const user = new _models_user__WEBPACK_IMPORTED_MODULE_1__["default"]({
        name,
        email,
        password: hashpassword
      });
      user.save().then(data => {
        return res.status(200).json({
          message: "you have successfuly registred"
        });
      }).catch(error => {
        return res.status(400).json({
          error: "something went wrong----"
        });
      });
    }
  } catch (error) {
    return res.status(400).json({
      error: "something went wrong"
    });
  }
});

/***/ }),

/***/ "bcryptjs":
/*!***************************!*\
  !*** external "bcryptjs" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("bcryptjs");

/***/ }),

/***/ "chalk":
/*!************************!*\
  !*** external "chalk" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("chalk");

/***/ }),

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mongoose");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vaGVscGVycy9pbml0REIuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kZWxzL3VzZXIuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2xvZ2luLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcImJjcnlwdGpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiY2hhbGtcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJqc29ud2VidG9rZW5cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJtb25nb29zZVwiIl0sIm5hbWVzIjpbImluaXREQiIsIm1vbmdvb3NlIiwiY29ubmVjdGlvbnMiLCJyZWFkeVN0YXRlIiwiY29uc29sZSIsImxvZyIsImNoYWxrIiwiZ3JlZW4iLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIk1PTkdPX1VSSSIsInVzZU5ld1VybFBhcnNlciIsInVzZVVuaWZpZWRUb3BvbG9neSIsImNvbm5lY3Rpb24iLCJvbiIsImJnR3JlZW4iLCJlcnJvciIsImJnUmVkIiwidXNlclNjaGVtYSIsIlNjaGVtYSIsIm5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJlbWFpbCIsInVuaXF1ZSIsInBhc3N3b3JkIiwicm9sZSIsImRlZmF1bHQiLCJlbnVtIiwidGltZXN0YW1wcyIsIm1vZGVscyIsInVzZXIiLCJtb2RlbCIsInJlcSIsInJlcyIsImJvZHkiLCJzdGF0dXMiLCJqc29uIiwibWVzc2FnZSIsInVzZXJkYXRhIiwiVXNlciIsImZpbmRPbmUiLCJkb21hdGNoIiwiQmNyeXB0IiwiY29tcGFyZSIsInRva2VuIiwiand0Iiwic2lnbiIsInVzZUlkIiwiX2lkIiwiSldUX1NFQ1JFVCIsImV4cGlyZXNJbiIsImhhc2hwYXNzd29yZCIsInNhdmUiLCJ0aGVuIiwiZGF0YSIsImNhdGNoIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDeEZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBOztBQUVBLFNBQVNBLE1BQVQsR0FBaUI7QUFDYixNQUFHQywrQ0FBUSxDQUFDQyxXQUFULENBQXFCLENBQXJCLEVBQXdCQyxVQUEzQixFQUNBO0FBQ0lDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZQyw0Q0FBSyxDQUFDQyxLQUFOLENBQVksaUNBQVosQ0FBWjtBQUNBO0FBQ0g7O0FBQ0ROLGlEQUFRLENBQUNPLE9BQVQsQ0FBaUJDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxTQUE3QixFQUF1QztBQUNuQztBQUNBQyxtQkFBZSxFQUFDLElBRm1CO0FBR25DQyxzQkFBa0IsRUFBQyxJQUhnQixDQUluQzs7QUFKbUMsR0FBdkM7QUFNQVosaURBQVEsQ0FBQ2EsVUFBVCxDQUFvQkMsRUFBcEIsQ0FBdUIsVUFBdkIsRUFBa0MsTUFBSTtBQUNsQ1gsV0FBTyxDQUFDQyxHQUFSLENBQVlDLDRDQUFLLENBQUNVLE9BQU4sQ0FBYyxvQkFBZCxDQUFaO0FBQ0gsR0FGRDtBQUdBZixpREFBUSxDQUFDYSxVQUFULENBQW9CQyxFQUFwQixDQUF1QixPQUF2QixFQUFnQ0UsS0FBRCxJQUFTO0FBQ3BDYixXQUFPLENBQUNDLEdBQVIsQ0FBWUMsNENBQUssQ0FBQ1ksS0FBTixDQUFZLE9BQVosRUFBb0JELEtBQXBCLENBQVo7QUFDSCxHQUZEO0FBR0g7O0FBRWNqQixxRUFBZixFOzs7Ozs7Ozs7Ozs7QUN2QkE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNbUIsVUFBVSxHQUFHLElBQUlsQiwrQ0FBUSxDQUFDbUIsTUFBYixDQUFvQjtBQUNuQ0MsTUFBSSxFQUFDO0FBQ0RDLFFBQUksRUFBQ0MsTUFESjtBQUVEQyxZQUFRLEVBQUM7QUFGUixHQUQ4QjtBQUtuQ0MsT0FBSyxFQUFDO0FBQ0ZILFFBQUksRUFBQ0MsTUFESDtBQUVGQyxZQUFRLEVBQUMsSUFGUDtBQUdGRSxVQUFNLEVBQUM7QUFITCxHQUw2QjtBQVVuQ0MsVUFBUSxFQUFDO0FBQ0xMLFFBQUksRUFBQ0MsTUFEQTtBQUVMQyxZQUFRLEVBQUM7QUFGSixHQVYwQjtBQWNuQ0ksTUFBSSxFQUFDO0FBQ0ROLFFBQUksRUFBQ0MsTUFESjtBQUVEQyxZQUFRLEVBQUMsSUFGUjtBQUdESyxXQUFPLEVBQUMsTUFIUDtBQUlEQyxRQUFJLEVBQUMsQ0FBQyxNQUFELEVBQVEsT0FBUixFQUFnQixNQUFoQjtBQUpKO0FBZDhCLENBQXBCLEVBb0JqQjtBQUNFQyxZQUFVLEVBQUM7QUFEYixDQXBCaUIsQ0FBbkI7QUF3QmU5Qiw4R0FBUSxDQUFDK0IsTUFBVCxDQUFnQkMsSUFBaEIsSUFBd0JoQywrQ0FBUSxDQUFDaUMsS0FBVCxDQUFlLE1BQWYsRUFBc0JmLFVBQXRCLENBQXZDLEU7Ozs7Ozs7Ozs7OztBQzFCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRUFuQiwrREFBTTtBQUVTLHNFQUFNbUMsR0FBTixFQUFVQyxHQUFWLEtBQWlCO0FBQzVCLE1BQUc7QUFDQyxVQUFNO0FBQUNYLFdBQUQ7QUFBT0U7QUFBUCxRQUFtQlEsR0FBRyxDQUFDRSxJQUE3Qjs7QUFDQSxRQUFHLENBQUNaLEtBQUQsSUFBVSxDQUFDRSxRQUFkLEVBQ0E7QUFDSSxhQUFPUyxHQUFHLENBQUNFLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUN4QkMsZUFBTyxFQUFDO0FBRGdCLE9BQXJCLENBQVA7QUFHSDs7QUFDRCxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsb0RBQUksQ0FBQ0MsT0FBTCxDQUFhO0FBQUNsQjtBQUFELEtBQWIsQ0FBdkI7O0FBQ0EsUUFBRyxDQUFDZ0IsUUFBSixFQUNBO0FBQ0ksYUFBT0wsR0FBRyxDQUFDRSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDeEJ0QixhQUFLLEVBQUM7QUFEa0IsT0FBckIsQ0FBUDtBQUdILEtBTEQsTUFPQTtBQUNJLFlBQU0yQixPQUFPLEdBQUcsTUFBTUMsK0NBQU0sQ0FBQ0MsT0FBUCxDQUFlbkIsUUFBZixFQUF3QmMsUUFBUSxDQUFDZCxRQUFqQyxDQUF0Qjs7QUFDQSxVQUFHaUIsT0FBSCxFQUNBO0FBQ0ksY0FBTUcsS0FBSyxHQUFHQyxtREFBRyxDQUFDQyxJQUFKLENBQVM7QUFBQ0MsZUFBSyxFQUFDVCxRQUFRLENBQUNVO0FBQWhCLFNBQVQsRUFBOEIxQyxPQUFPLENBQUNDLEdBQVIsQ0FBWTBDLFVBQTFDLEVBQXFEO0FBQy9EQyxtQkFBUyxFQUFDO0FBRHFELFNBQXJELENBQWQ7QUFHQSxlQUFPakIsR0FBRyxDQUFDRSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDdkJRLGVBQUssRUFBQ0EsS0FEaUI7QUFFdkJQLGlCQUFPLEVBQUM7QUFGZSxTQUFyQixDQUFQO0FBSUgsT0FURCxNQVdBO0FBQ0lKLFdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ2pCdEIsZUFBSyxFQUFDO0FBRFcsU0FBckI7QUFHSDs7QUFDRCxZQUFNZ0IsSUFBSSxHQUFHLElBQUlTLG9EQUFKLENBQVM7QUFDbEJyQixZQURrQjtBQUVsQkksYUFGa0I7QUFHbEJFLGdCQUFRLEVBQUMyQjtBQUhTLE9BQVQsQ0FBYjtBQUtBckIsVUFBSSxDQUFDc0IsSUFBTCxHQUFZQyxJQUFaLENBQWtCQyxJQUFELElBQVU7QUFDdkIsZUFBT3JCLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ3hCQyxpQkFBTyxFQUFDO0FBRGdCLFNBQXJCLENBQVA7QUFHSCxPQUpELEVBSUdrQixLQUpILENBSVV6QyxLQUFELElBQVc7QUFDaEIsZUFBT21CLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ3hCdEIsZUFBSyxFQUFDO0FBRGtCLFNBQXJCLENBQVA7QUFHSCxPQVJEO0FBU0g7QUFDSixHQWpERCxDQWtEQSxPQUFNQSxLQUFOLEVBQ0E7QUFDSSxXQUFPbUIsR0FBRyxDQUFDRSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDeEJ0QixXQUFLLEVBQUM7QUFEa0IsS0FBckIsQ0FBUDtBQUdIO0FBQ0osQ0F6REQsRTs7Ozs7Ozs7Ozs7QUNQQSxxQzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSx5Qzs7Ozs7Ozs7Ozs7QUNBQSxxQyIsImZpbGUiOiJwYWdlcy9hcGkvbG9naW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uLy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2FwaS9sb2dpbi5qc1wiKTtcbiIsImltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcbmltcG9ydCBjaGFsayBmcm9tICdjaGFsayc7XHJcblxyXG5mdW5jdGlvbiBpbml0REIoKXtcclxuICAgIGlmKG1vbmdvb3NlLmNvbm5lY3Rpb25zWzBdLnJlYWR5U3RhdGUpXHJcbiAgICB7XHJcbiAgICAgICAgY29uc29sZS5sb2coY2hhbGsuZ3JlZW4oXCJhbGVyYWR5IGNvbm5lY3RlZCB0byBhIGRhdGFiYXNlXCIpKTtcclxuICAgICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIG1vbmdvb3NlLmNvbm5lY3QocHJvY2Vzcy5lbnYuTU9OR09fVVJJLHtcclxuICAgICAgICAvLyB1c2VDcmVhdGVJbmRleDp0cnVlLFxyXG4gICAgICAgIHVzZU5ld1VybFBhcnNlcjp0cnVlLFxyXG4gICAgICAgIHVzZVVuaWZpZWRUb3BvbG9neTp0cnVlLFxyXG4gICAgICAgIC8vIHVzZUZpbmRBbmRNb2RpZnk6dHJ1ZVxyXG4gICAgfSlcclxuICAgIG1vbmdvb3NlLmNvbm5lY3Rpb24ub24oXCJjb25uZXRlZFwiLCgpPT57XHJcbiAgICAgICAgY29uc29sZS5sb2coY2hhbGsuYmdHcmVlbihcIk1vbmdvZGIgdG8gY29ubmVjdFwiKSlcclxuICAgIH0pXHJcbiAgICBtb25nb29zZS5jb25uZWN0aW9uLm9uKFwiZXJyb3JcIiwoZXJyb3IpPT57XHJcbiAgICAgICAgY29uc29sZS5sb2coY2hhbGsuYmdSZWQoXCJFcnJvclwiLGVycm9yKSk7XHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBpbml0REI7IiwiaW1wb3J0IG1vbmdvb3NlIGZyb20gJ21vbmdvb3NlJztcclxuXHJcbmNvbnN0IHVzZXJTY2hlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcclxuICAgIG5hbWU6e1xyXG4gICAgICAgIHR5cGU6U3RyaW5nLFxyXG4gICAgICAgIHJlcXVpcmVkOnRydWVcclxuICAgIH0sXHJcbiAgICBlbWFpbDp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6dHJ1ZSxcclxuICAgICAgICB1bmlxdWU6dHJ1ZVxyXG4gICAgfSxcclxuICAgIHBhc3N3b3JkOntcclxuICAgICAgICB0eXBlOlN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDp0cnVlXHJcbiAgICB9LFxyXG4gICAgcm9sZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6dHJ1ZSxcclxuICAgICAgICBkZWZhdWx0Oid1c2VyJyxcclxuICAgICAgICBlbnVtOltcInVzZXJcIixcImFkbWluXCIsXCJyb290XCJdXHJcbiAgICB9XHJcbn0se1xyXG4gICAgdGltZXN0YW1wczp0cnVlXHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgbW9uZ29vc2UubW9kZWxzLnVzZXIgfHwgbW9uZ29vc2UubW9kZWwoXCJ1c2VyXCIsdXNlclNjaGVtYSk7IiwiaW1wb3J0IGluaXREQiBmcm9tICcuLi8uLi9oZWxwZXJzL2luaXREQic7XHJcbmltcG9ydCBVc2VyIGZyb20gJy4uLy4uL21vZGVscy91c2VyJztcclxuaW1wb3J0IEJjcnlwdCBmcm9tICdiY3J5cHRqcyc7XHJcbmltcG9ydCBqd3QgZnJvbSAnanNvbndlYnRva2VuJzsgXHJcblxyXG5pbml0REIoKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jKHJlcSxyZXMpPT4ge1xyXG4gICAgdHJ5e1xyXG4gICAgICAgIGNvbnN0IHtlbWFpbCxwYXNzd29yZH0gPSByZXEuYm9keTtcclxuICAgICAgICBpZighZW1haWwgfHwgIXBhc3N3b3JkKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDIyKS5qc29uKHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6XCJwbGVhc2UgYWRkIGFsbCBmaWxlZFwiXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHVzZXJkYXRhID0gYXdhaXQgVXNlci5maW5kT25lKHtlbWFpbH0pO1xyXG4gICAgICAgIGlmKCF1c2VyZGF0YSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwMSkuanNvbih7XHJcbiAgICAgICAgICAgICAgICBlcnJvcjonVXNlciBkb3NlIG5vdCBleGl0IHdpdGggdGhhdCBlbWFpbCdcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgY29uc3QgZG9tYXRjaCA9IGF3YWl0IEJjcnlwdC5jb21wYXJlKHBhc3N3b3JkLHVzZXJkYXRhLnBhc3N3b3JkKTtcclxuICAgICAgICAgICAgaWYoZG9tYXRjaClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdG9rZW4gPSBqd3Quc2lnbih7dXNlSWQ6dXNlcmRhdGEuX2lkfSxwcm9jZXNzLmVudi5KV1RfU0VDUkVULHtcclxuICAgICAgICAgICAgICAgICAgICBleHBpcmVzSW46XCI3ZFwiXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtcclxuICAgICAgICAgICAgICAgICAgICAgdG9rZW46dG9rZW4sXHJcbiAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6XCJ5b3UgaGF2ZSB0byBzdWNjZXNzZnVseSBsb2dpblwiXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmVzLnN0YXR1cyg0MDEpLmpzb24oe1xyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOlwiZW1haWwgYW5kIHBhc3N3b3JkIGRvIG5vdCBtYXRjaFwiXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBuZXcgVXNlcih7XHJcbiAgICAgICAgICAgICAgICBuYW1lLFxyXG4gICAgICAgICAgICAgICAgZW1haWwsXHJcbiAgICAgICAgICAgICAgICBwYXNzd29yZDpoYXNocGFzc3dvcmRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHVzZXIuc2F2ZSgpLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTpcInlvdSBoYXZlIHN1Y2Nlc3NmdWx5IHJlZ2lzdHJlZFwiXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7XHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6XCJzb21ldGhpbmcgd2VudCB3cm9uZy0tLS1cIlxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnJvcilcclxuICAgIHtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe1xyXG4gICAgICAgICAgICBlcnJvcjpcInNvbWV0aGluZyB3ZW50IHdyb25nXCJcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG59XHJcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImJjcnlwdGpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNoYWxrXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImpzb253ZWJ0b2tlblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtb25nb29zZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9