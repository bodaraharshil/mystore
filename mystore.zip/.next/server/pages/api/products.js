module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/api/products.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./helpers/initDB.js":
/*!***************************!*\
  !*** ./helpers/initDB.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ "mongoose");
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_1__);



function initDB() {
  if (mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connections[0].readyState) {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.green("alerady connected to a database"));
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connect(process.env.MONGO_URI, {
    // useCreateIndex:true,
    useNewUrlParser: true,
    useUnifiedTopology: true // useFindAndModify:true

  });
  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connection.on("conneted", () => {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.bgGreen("Mongodb to connect"));
  });
  mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.connection.on("error", error => {
    console.log(chalk__WEBPACK_IMPORTED_MODULE_1___default.a.bgRed("Error", error));
  });
}

/* harmony default export */ __webpack_exports__["default"] = (initDB);

/***/ }),

/***/ "./models/product.js":
/*!***************************!*\
  !*** ./models/product.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ "mongoose");
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const Productshcema = new mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.Schema({
  name: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  mediaurl: {
    type: String,
    required: true
  }
});
const product = mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.models.product || mongoose__WEBPACK_IMPORTED_MODULE_0___default.a.model('product', Productshcema);
/* harmony default export */ __webpack_exports__["default"] = (product);

/***/ }),

/***/ "./pages/api/products.js":
/*!*******************************!*\
  !*** ./pages/api/products.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers_initDB__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers/initDB */ "./helpers/initDB.js");
/* harmony import */ var _models_product__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../models/product */ "./models/product.js");


Object(_helpers_initDB__WEBPACK_IMPORTED_MODULE_0__["default"])();
/* harmony default export */ __webpack_exports__["default"] = (async (req, res) => {
  switch (req.method) {
    case "GET":
      await getAllProduct(req, res);
      break;

    case "POST":
      await saveProduct(req, res);
      break;
  }
});

const getAllProduct = async (req, res) => {
  try {
    await _models_product__WEBPACK_IMPORTED_MODULE_1__["default"].find().then(data => {
      res.status(200).json({
        message: 'get product data',
        data: data
      });
    }).catch(error => {
      res.status(400).json({
        error: "something went wrong"
      });
    });
  } catch (error) {
    res.send({
      status: 400,
      message: 'something went wrong'
    });
  }
};

const saveProduct = async (req, res) => {
  try {
    const {
      name,
      price,
      description,
      mediaurl
    } = req.body;

    if (!name || !price || !description || !mediaurl) {
      return res.status(422).json({
        error: "please add all the fields"
      });
    }

    const productdata = await new _models_product__WEBPACK_IMPORTED_MODULE_1__["default"]({
      name,
      price,
      description,
      mediaurl
    });
    productdata.save().then(data => {
      res.status(200).json({
        message: 'product add successfuly'
      });
    }).catch(eror => {
      res.status(400).json({
        error: "something went wrong--1"
      });
    });
  } catch (error) {
    res.send({
      status: 400,
      message: 'something went wrong'
    });
  }
};

/***/ }),

/***/ "chalk":
/*!************************!*\
  !*** external "chalk" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("chalk");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mongoose");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vaGVscGVycy9pbml0REIuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kZWxzL3Byb2R1Y3QuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL3Byb2R1Y3RzLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcImNoYWxrXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibW9uZ29vc2VcIiJdLCJuYW1lcyI6WyJpbml0REIiLCJtb25nb29zZSIsImNvbm5lY3Rpb25zIiwicmVhZHlTdGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJjaGFsayIsImdyZWVuIiwiY29ubmVjdCIsInByb2Nlc3MiLCJlbnYiLCJNT05HT19VUkkiLCJ1c2VOZXdVcmxQYXJzZXIiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJjb25uZWN0aW9uIiwib24iLCJiZ0dyZWVuIiwiZXJyb3IiLCJiZ1JlZCIsIlByb2R1Y3RzaGNlbWEiLCJTY2hlbWEiLCJuYW1lIiwidHlwZSIsIlN0cmluZyIsInJlcXVpcmVkIiwicHJpY2UiLCJkZXNjcmlwdGlvbiIsIm1lZGlhdXJsIiwicHJvZHVjdCIsIm1vZGVscyIsIm1vZGVsIiwicmVxIiwicmVzIiwibWV0aG9kIiwiZ2V0QWxsUHJvZHVjdCIsInNhdmVQcm9kdWN0IiwiUHJvZHVjdCIsImZpbmQiLCJ0aGVuIiwiZGF0YSIsInN0YXR1cyIsImpzb24iLCJtZXNzYWdlIiwiY2F0Y2giLCJzZW5kIiwiYm9keSIsInByb2R1Y3RkYXRhIiwic2F2ZSIsImVyb3IiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN4RkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBRUEsU0FBU0EsTUFBVCxHQUFpQjtBQUNiLE1BQUdDLCtDQUFRLENBQUNDLFdBQVQsQ0FBcUIsQ0FBckIsRUFBd0JDLFVBQTNCLEVBQ0E7QUFDSUMsV0FBTyxDQUFDQyxHQUFSLENBQVlDLDRDQUFLLENBQUNDLEtBQU4sQ0FBWSxpQ0FBWixDQUFaO0FBQ0E7QUFDSDs7QUFDRE4saURBQVEsQ0FBQ08sT0FBVCxDQUFpQkMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFNBQTdCLEVBQXVDO0FBQ25DO0FBQ0FDLG1CQUFlLEVBQUMsSUFGbUI7QUFHbkNDLHNCQUFrQixFQUFDLElBSGdCLENBSW5DOztBQUptQyxHQUF2QztBQU1BWixpREFBUSxDQUFDYSxVQUFULENBQW9CQyxFQUFwQixDQUF1QixVQUF2QixFQUFrQyxNQUFJO0FBQ2xDWCxXQUFPLENBQUNDLEdBQVIsQ0FBWUMsNENBQUssQ0FBQ1UsT0FBTixDQUFjLG9CQUFkLENBQVo7QUFDSCxHQUZEO0FBR0FmLGlEQUFRLENBQUNhLFVBQVQsQ0FBb0JDLEVBQXBCLENBQXVCLE9BQXZCLEVBQWdDRSxLQUFELElBQVM7QUFDcENiLFdBQU8sQ0FBQ0MsR0FBUixDQUFZQyw0Q0FBSyxDQUFDWSxLQUFOLENBQVksT0FBWixFQUFvQkQsS0FBcEIsQ0FBWjtBQUNILEdBRkQ7QUFHSDs7QUFFY2pCLHFFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1tQixhQUFhLEdBQUcsSUFBSWxCLCtDQUFRLENBQUNtQixNQUFiLENBQW9CO0FBQ3RDQyxNQUFJLEVBQUM7QUFDREMsUUFBSSxFQUFDQyxNQURKO0FBRURDLFlBQVEsRUFBQztBQUZSLEdBRGlDO0FBS3RDQyxPQUFLLEVBQUM7QUFDRkgsUUFBSSxFQUFDQyxNQURIO0FBRUZDLFlBQVEsRUFBQztBQUZQLEdBTGdDO0FBU3RDRSxhQUFXLEVBQUM7QUFDUkosUUFBSSxFQUFDQyxNQURHO0FBRVJDLFlBQVEsRUFBQztBQUZELEdBVDBCO0FBYXRDRyxVQUFRLEVBQUM7QUFDTEwsUUFBSSxFQUFDQyxNQURBO0FBRUxDLFlBQVEsRUFBQztBQUZKO0FBYjZCLENBQXBCLENBQXRCO0FBbUJBLE1BQU1JLE9BQU8sR0FBRzNCLCtDQUFRLENBQUM0QixNQUFULENBQWdCRCxPQUFoQixJQUEyQjNCLCtDQUFRLENBQUM2QixLQUFULENBQWUsU0FBZixFQUEwQlgsYUFBMUIsQ0FBM0M7QUFFZVMsc0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQTVCLCtEQUFNO0FBRVMsc0VBQU0rQixHQUFOLEVBQVVDLEdBQVYsS0FBa0I7QUFFL0IsVUFBT0QsR0FBRyxDQUFDRSxNQUFYO0FBRUUsU0FBSyxLQUFMO0FBQ0UsWUFBTUMsYUFBYSxDQUFDSCxHQUFELEVBQUtDLEdBQUwsQ0FBbkI7QUFDQTs7QUFDRixTQUFLLE1BQUw7QUFDRSxZQUFNRyxXQUFXLENBQUNKLEdBQUQsRUFBS0MsR0FBTCxDQUFqQjtBQUNBO0FBUEo7QUFTQSxDQVhGOztBQWFDLE1BQU1FLGFBQWEsR0FBRyxPQUFNSCxHQUFOLEVBQVVDLEdBQVYsS0FBa0I7QUFDdkMsTUFDQTtBQUNFLFVBQU1JLHVEQUFPLENBQUNDLElBQVIsR0FBZUMsSUFBZixDQUFxQkMsSUFBRCxJQUFVO0FBQ2xDUCxTQUFHLENBQUNRLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUNuQkMsZUFBTyxFQUFDLGtCQURXO0FBRW5CSCxZQUFJLEVBQUNBO0FBRmMsT0FBckI7QUFJRCxLQUxLLEVBS0hJLEtBTEcsQ0FLSTFCLEtBQUQsSUFBVztBQUNsQmUsU0FBRyxDQUFDUSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJ4QixhQUFLLEVBQUM7QUFEYSxPQUFyQjtBQUdELEtBVEssQ0FBTjtBQVVELEdBWkQsQ0FhQSxPQUFNQSxLQUFOLEVBQ0E7QUFDRWUsT0FBRyxDQUFDWSxJQUFKLENBQVM7QUFDUEosWUFBTSxFQUFDLEdBREE7QUFFUEUsYUFBTyxFQUFDO0FBRkQsS0FBVDtBQUlEO0FBQ0QsQ0FyQkQ7O0FBdUJBLE1BQU1QLFdBQVcsR0FBRyxPQUFNSixHQUFOLEVBQVVDLEdBQVYsS0FBa0I7QUFDckMsTUFDQTtBQUNFLFVBQU07QUFBQ1gsVUFBRDtBQUFNSSxXQUFOO0FBQVlDLGlCQUFaO0FBQXdCQztBQUF4QixRQUFvQ0ksR0FBRyxDQUFDYyxJQUE5Qzs7QUFDQSxRQUFHLENBQUN4QixJQUFELElBQVMsQ0FBQ0ksS0FBVixJQUFtQixDQUFDQyxXQUFwQixJQUFtQyxDQUFDQyxRQUF2QyxFQUNBO0FBQ0UsYUFBT0ssR0FBRyxDQUFDUSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDMUJ4QixhQUFLLEVBQUM7QUFEb0IsT0FBckIsQ0FBUDtBQUdEOztBQUNELFVBQU02QixXQUFXLEdBQUcsTUFBTSxJQUFJVix1REFBSixDQUFZO0FBQ3BDZixVQURvQztBQUVwQ0ksV0FGb0M7QUFHcENDLGlCQUhvQztBQUlwQ0M7QUFKb0MsS0FBWixDQUExQjtBQU1BbUIsZUFBVyxDQUFDQyxJQUFaLEdBQW1CVCxJQUFuQixDQUF5QkMsSUFBRCxJQUFVO0FBQ2hDUCxTQUFHLENBQUNRLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUNuQkMsZUFBTyxFQUFDO0FBRFcsT0FBckI7QUFHRCxLQUpELEVBSUdDLEtBSkgsQ0FJVUssSUFBRCxJQUFVO0FBQ2pCaEIsU0FBRyxDQUFDUSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJ4QixhQUFLLEVBQUM7QUFEYSxPQUFyQjtBQUdELEtBUkQ7QUFVRCxHQXpCRCxDQTBCQSxPQUFNQSxLQUFOLEVBQ0E7QUFDRWUsT0FBRyxDQUFDWSxJQUFKLENBQVM7QUFDUEosWUFBTSxFQUFDLEdBREE7QUFFUEUsYUFBTyxFQUFDO0FBRkQsS0FBVDtBQUlEO0FBQ0QsQ0FsQ0QsQzs7Ozs7Ozs7Ozs7QUN6Q0Qsa0M7Ozs7Ozs7Ozs7O0FDQUEscUMiLCJmaWxlIjoicGFnZXMvYXBpL3Byb2R1Y3RzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi8uLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9wYWdlcy9hcGkvcHJvZHVjdHMuanNcIik7XG4iLCJpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5pbXBvcnQgY2hhbGsgZnJvbSAnY2hhbGsnO1xyXG5cclxuZnVuY3Rpb24gaW5pdERCKCl7XHJcbiAgICBpZihtb25nb29zZS5jb25uZWN0aW9uc1swXS5yZWFkeVN0YXRlKVxyXG4gICAge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGNoYWxrLmdyZWVuKFwiYWxlcmFkeSBjb25uZWN0ZWQgdG8gYSBkYXRhYmFzZVwiKSk7XHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICB9XHJcbiAgICBtb25nb29zZS5jb25uZWN0KHByb2Nlc3MuZW52Lk1PTkdPX1VSSSx7XHJcbiAgICAgICAgLy8gdXNlQ3JlYXRlSW5kZXg6dHJ1ZSxcclxuICAgICAgICB1c2VOZXdVcmxQYXJzZXI6dHJ1ZSxcclxuICAgICAgICB1c2VVbmlmaWVkVG9wb2xvZ3k6dHJ1ZSxcclxuICAgICAgICAvLyB1c2VGaW5kQW5kTW9kaWZ5OnRydWVcclxuICAgIH0pXHJcbiAgICBtb25nb29zZS5jb25uZWN0aW9uLm9uKFwiY29ubmV0ZWRcIiwoKT0+e1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGNoYWxrLmJnR3JlZW4oXCJNb25nb2RiIHRvIGNvbm5lY3RcIikpXHJcbiAgICB9KVxyXG4gICAgbW9uZ29vc2UuY29ubmVjdGlvbi5vbihcImVycm9yXCIsKGVycm9yKT0+e1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGNoYWxrLmJnUmVkKFwiRXJyb3JcIixlcnJvcikpO1xyXG4gICAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgaW5pdERCOyIsImltcG9ydCBtb25nb29zZSx7IG1vZGVscyB9IGZyb20gJ21vbmdvb3NlJztcclxuXHJcbmNvbnN0IFByb2R1Y3RzaGNlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcclxuICAgIG5hbWU6e1xyXG4gICAgICAgIHR5cGU6U3RyaW5nLFxyXG4gICAgICAgIHJlcXVpcmVkOnRydWVcclxuICAgIH0sXHJcbiAgICBwcmljZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6dHJ1ZVxyXG4gICAgfSxcclxuICAgIGRlc2NyaXB0aW9uOntcclxuICAgICAgICB0eXBlOlN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDp0cnVlXHJcbiAgICB9LFxyXG4gICAgbWVkaWF1cmw6e1xyXG4gICAgICAgIHR5cGU6U3RyaW5nLFxyXG4gICAgICAgIHJlcXVpcmVkOnRydWVcclxuICAgIH0sXHJcbn0pXHJcblxyXG5jb25zdCBwcm9kdWN0ID0gbW9uZ29vc2UubW9kZWxzLnByb2R1Y3QgfHwgbW9uZ29vc2UubW9kZWwoJ3Byb2R1Y3QnLCBQcm9kdWN0c2hjZW1hKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHByb2R1Y3Q7IiwiaW1wb3J0IGluaXREQiBmcm9tICcuLi8uLi9oZWxwZXJzL2luaXREQic7XHJcbmltcG9ydCBQcm9kdWN0IGZyb20gJy4uLy4uL21vZGVscy9wcm9kdWN0J1xyXG5cclxuaW5pdERCKClcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jKHJlcSxyZXMpID0+IHtcclxuXHJcbiAgc3dpdGNoKHJlcS5tZXRob2QpXHJcbiAge1xyXG4gICAgY2FzZSBcIkdFVFwiOlxyXG4gICAgICBhd2FpdCBnZXRBbGxQcm9kdWN0KHJlcSxyZXMpO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgXCJQT1NUXCI6XHJcbiAgICAgIGF3YWl0IHNhdmVQcm9kdWN0KHJlcSxyZXMpO1xyXG4gICAgICBicmVhaztcclxuICB9XHJcbiB9XHJcblxyXG4gY29uc3QgZ2V0QWxsUHJvZHVjdCA9IGFzeW5jKHJlcSxyZXMpID0+IHtcclxuICB0cnlcclxuICB7XHJcbiAgICBhd2FpdCBQcm9kdWN0LmZpbmQoKS50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtcclxuICAgICAgICBtZXNzYWdlOidnZXQgcHJvZHVjdCBkYXRhJyxcclxuICAgICAgICBkYXRhOmRhdGFcclxuICAgICAgfSlcclxuICAgIH0pLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICByZXMuc3RhdHVzKDQwMCkuanNvbih7XHJcbiAgICAgICAgZXJyb3I6XCJzb21ldGhpbmcgd2VudCB3cm9uZ1wiLCBcclxuICAgICAgfSlcclxuICAgIH0pXHJcbiAgfVxyXG4gIGNhdGNoKGVycm9yKVxyXG4gIHtcclxuICAgIHJlcy5zZW5kKHtcclxuICAgICAgc3RhdHVzOjQwMCxcclxuICAgICAgbWVzc2FnZTonc29tZXRoaW5nIHdlbnQgd3JvbmcnLFxyXG4gICAgfSlcclxuICB9XHJcbiB9IFxyXG5cclxuIGNvbnN0IHNhdmVQcm9kdWN0ID0gYXN5bmMocmVxLHJlcykgPT4ge1xyXG4gIHRyeVxyXG4gIHtcclxuICAgIGNvbnN0IHtuYW1lLHByaWNlLGRlc2NyaXB0aW9uLG1lZGlhdXJsfSA9IHJlcS5ib2R5O1xyXG4gICAgaWYoIW5hbWUgfHwgIXByaWNlIHx8ICFkZXNjcmlwdGlvbiB8fCAhbWVkaWF1cmwpXHJcbiAgICB7XHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQyMikuanNvbih7XHJcbiAgICAgICAgZXJyb3I6XCJwbGVhc2UgYWRkIGFsbCB0aGUgZmllbGRzXCJcclxuICAgICAgfSlcclxuICAgIH1cclxuICAgIGNvbnN0IHByb2R1Y3RkYXRhID0gYXdhaXQgbmV3IFByb2R1Y3Qoe1xyXG4gICAgICBuYW1lLFxyXG4gICAgICBwcmljZSxcclxuICAgICAgZGVzY3JpcHRpb24sXHJcbiAgICAgIG1lZGlhdXJsICAgICAgXHJcbiAgICB9KTtcclxuICAgIHByb2R1Y3RkYXRhLnNhdmUoKS50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtcclxuICAgICAgICBtZXNzYWdlOidwcm9kdWN0IGFkZCBzdWNjZXNzZnVseSdcclxuICAgICAgfSlcclxuICAgIH0pLmNhdGNoKChlcm9yKSA9PiB7XHJcbiAgICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcclxuICAgICAgICBlcnJvcjpcInNvbWV0aGluZyB3ZW50IHdyb25nLS0xXCJcclxuICAgICAgfSlcclxuICAgIH0pXHJcblxyXG4gIH1cclxuICBjYXRjaChlcnJvcilcclxuICB7XHJcbiAgICByZXMuc2VuZCh7XHJcbiAgICAgIHN0YXR1czo0MDAsXHJcbiAgICAgIG1lc3NhZ2U6J3NvbWV0aGluZyB3ZW50IHdyb25nJyxcclxuICAgIH0pXHJcbiAgfVxyXG4gfSIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNoYWxrXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm1vbmdvb3NlXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=